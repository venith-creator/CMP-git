//data.js
export let expenses = [];